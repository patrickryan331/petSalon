

// var globalVariable = "I'm in global scope";

// function myFunction() {
//     // This function can access globalVariable
//     console.log(globalVariable);
// }

// myFunction();




// function myFunction() {
//     var localVariable = "I'm in local scope"
//     console.log(localVariable);
// }

// myFunction();
// // Accessing this localVariable here would result in an error




// object literal

let student1 = {
    name: "Patrick",
    email: "patrick@email.com",
    grade101: 3.5,
    grade102: 3.9,
}

let student2 = {
    name: "Floyd",
    email: "floyd@email.com",
    grade101: 3.2,
    grade102: 3.3,
}

let student3 = {
    name: "Lyss",
    email: "lyss@email.com",
    grade101: 3.9,
    grade102: 3.8,
}

console.log(student1);
console.log(student2);
console.log(student3);


//Array []
let myArray=[10,false,"richard",student2]
console.log(myArray[2]); //richard